# Solicitud Almacén

Proyecto Android de solicitudes de productos entre tiendas y almacén, con Firebase Authentication y Cloud Firestore.

## Corrección del pedido de tienda

- Las cantidades se seleccionan en el catálogo y quedan como borrador local; no actualizan el stock de Firestore.
- La barra inferior muestra siempre los botones **Cancelar pedido** y **Enviar solicitud** en la pestaña Productos.
- **Cancelar pedido** vacía las cantidades seleccionadas sin crear una solicitud.
- **Enviar solicitud** crea un documento en `requests`; al completarse, limpia el borrador y abre la pestaña Mis pedidos.
- Mientras se envía, el botón queda desactivado para evitar envíos duplicados.

## Datos de Firebase

- Colección `users`: un documento por UID de Firebase Authentication, con `role` igual a `store` o `warehouse`.
- Colección `productos`: campos `tipoProducto`, `marca`, `modelo`, `stock` y opcionalmente `active`.
- Colección `requests`: solicitudes enviadas por tiendas.

## Compilar

El workflow `.github/workflows/compilar-apk.yml` busca `settings.gradle.kts` o `settings.gradle` y compila `assembleDebug`. El APK se publica como artefacto `Solicitud-Almacen-APK`.

La compilación debe verificarse ejecutando GitHub Actions en el repositorio que contiene el proyecto y su `app/google-services.json` válido.
