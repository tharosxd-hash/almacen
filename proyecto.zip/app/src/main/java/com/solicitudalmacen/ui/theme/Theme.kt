package com.solicitudalmacen.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AlmacenBlue = Color(0xFF2F5D8A)
val AlmacenBlueDark = Color(0xFF1B3A5C)
val AlmacenTeal = Color(0xFF1FA697)

private val LightColors = lightColorScheme(
    primary = AlmacenBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD8E6F6),
    onPrimaryContainer = AlmacenBlueDark,
    secondary = AlmacenTeal,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCDEFEA),
    onSecondaryContainer = Color(0xFF0B4A43),
    background = Color(0xFFF6F8FB),
    onBackground = Color(0xFF1A1C1E),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFFE3E8ED),
    onSurfaceVariant = Color(0xFF5B6470),
    error = Color(0xFFD64545),
    errorContainer = Color(0xFFF8D7D7),
    onErrorContainer = Color(0xFF8A1F1F)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8FB8E0),
    onPrimary = Color(0xFF0B2A45),
    primaryContainer = Color(0xFF25405C),
    onPrimaryContainer = Color(0xFFD8E6F6),
    secondary = Color(0xFF6FD0C4),
    onSecondary = Color(0xFF073A34),
    secondaryContainer = Color(0xFF14504A),
    onSecondaryContainer = Color(0xFFCDEFEA),
    background = Color(0xFF10171F),
    onBackground = Color(0xFFE3E8ED),
    surface = Color(0xFF1A2330),
    onSurface = Color(0xFFE3E8ED),
    surfaceVariant = Color(0xFF2B3542),
    onSurfaceVariant = Color(0xFFB7C1CC),
    error = Color(0xFFFF8A80),
    errorContainer = Color(0xFF5C2323),
    onErrorContainer = Color(0xFFF8D7D7)
)

@Composable
fun SolicitudAlmacenTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = Typography(),
        content = content
    )
}
