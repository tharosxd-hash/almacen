package com.solicitudalmacen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.solicitudalmacen.data.AppUser
import com.solicitudalmacen.data.FirebaseRepository
import com.solicitudalmacen.data.Product
import com.solicitudalmacen.data.RequestItem
import com.solicitudalmacen.data.RequestStatus
import com.solicitudalmacen.data.StockRequest
import com.solicitudalmacen.data.UserRole
import com.solicitudalmacen.ui.theme.SolicitudAlmacenTheme
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SolicitudAlmacenTheme { App() } }
    }
}

@Composable
private fun App() {
    val repo = remember { FirebaseRepository() }
    var user by remember { mutableStateOf<AppUser?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        repo.loadCurrentUser { result ->
            loading = false
            result.onSuccess { user = it }.onFailure { error = it.message }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when {
            loading -> CenterLoading()
            user == null -> LoginScreen(repo, initialError = error) {
                user = it
                error = null
            }
            user!!.role == UserRole.STORE -> StoreScreen(repo, user!!) {
                repo.logout(); user = null
            }
            else -> WarehouseScreen(repo, user!!) {
                repo.logout(); user = null
            }
        }
    }
}

@Composable
private fun CenterLoading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
private fun LoginScreen(repo: FirebaseRepository, initialError: String?, onLoggedIn: (AppUser) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(initialError ?: "") }
    var showPassword by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Inventory2,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
            Text("Pedidos Almacén", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Ingresa con tu cuenta de tienda o almacén",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(32.dp))
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Correo") },
                leadingIcon = { Icon(Icons.Default.Email, null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Contraseña") },
                leadingIcon = { Icon(Icons.Default.Lock, null) },
                trailingIcon = {
                    IconButton(onClick = { showPassword = !showPassword }) {
                        Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                    }
                },
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            if (error.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    busy = true
                    repo.login(email, password) { result ->
                        busy = false
                        result.onSuccess(onLoggedIn).onFailure { error = it.message ?: "No se pudo iniciar sesión" }
                    }
                },
                enabled = !busy && email.isNotBlank() && password.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                if (busy) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("Entrar", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
private fun SearchField(query: String, onQueryChange: (String) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        placeholder = { Text("Buscar producto o SKU") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) { Icon(Icons.Default.Close, null) }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun EmptyState(icon: ImageVector, text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun StockBadge(stock: Double, unit: String) {
    val low = stock <= 5
    Surface(
        color = if (low) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(10.dp)
    ) {
        Text(
            "${formatQty(stock)} $unit",
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (low) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

@Composable
private fun StatusBadge(status: RequestStatus) {
    val text: String
    val container: Color
    val content: Color
    when (status) {
        RequestStatus.PENDING -> {
            text = "Pendiente"; container = Color(0xFFFCE7C3); content = Color(0xFF8A5A00)
        }
        RequestStatus.PREPARING -> {
            text = "Preparando"; container = Color(0xFFD8E6F6); content = Color(0xFF2F5D8A)
        }
        RequestStatus.READY -> {
            text = "Listo"; container = Color(0xFFD9F0DC); content = Color(0xFF276B34)
        }
        RequestStatus.REJECTED -> {
            text = "Rechazado"; container = Color(0xFFF8D7D7); content = Color(0xFFB3261E)
        }
    }
    Surface(color = container, shape = RoundedCornerShape(10.dp)) {
        Text(
            text,
            color = content,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun StoreScreen(repo: FirebaseRepository, user: AppUser, onLogout: () -> Unit) {
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var requests by remember { mutableStateOf<List<StockRequest>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Map<String, Double>>(emptyMap()) }
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    DisposableEffect(user.uid) {
        val productListener = repo.listenProducts({ products = it }, { error = it.message })
        val requestListener = repo.listenRequestsForStore(user.uid, { requests = it }, { error = it.message })
        onDispose { productListener.remove(); requestListener.remove() }
    }

    val filteredProducts = if (query.isBlank()) {
        products
    } else {
        products.filter { it.name.contains(query, ignoreCase = true) || it.sku.contains(query, ignoreCase = true) }
    }
    val itemsToSend = products.filter { (selected[it.id] ?: 0.0) > 0 }.map {
        RequestItem(it.id, it.name, it.sku, it.unit, selected[it.id] ?: 0.0)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Hola, ${user.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Tienda", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, contentDescription = "Salir") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Storefront, null) },
                    label = { Text("Catálogo") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = {
                        BadgedBox(badge = { if (requests.isNotEmpty()) Badge { Text("${requests.size}") } }) {
                            Icon(Icons.Default.Send, null)
                        }
                    },
                    label = { Text("Mis pedidos") }
                )
            }
        },
        floatingActionButton = {
            if (tab == 0 && itemsToSend.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = {
                        repo.sendRequest(user, itemsToSend) { result ->
                            result.onSuccess {
                                selected = emptyMap()
                                scope.launch { snackbarHostState.showSnackbar("Pedido enviado") }
                                tab = 1
                            }.onFailure { error = it.message }
                        }
                    },
                    icon = { Icon(Icons.Default.Send, null) },
                    text = { Text("Enviar (${itemsToSend.size})") }
                )
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
            }
            if (tab == 0) {
                SearchField(query) { query = it }
                StoreProductList(filteredProducts, selected) { id, qty ->
                    selected = selected.toMutableMap().apply { if (qty <= 0) remove(id) else put(id, qty) }
                }
            } else {
                RequestList(requests)
            }
        }
    }
}

@Composable
private fun StoreProductList(products: List<Product>, selected: Map<String, Double>, onQtyChange: (String, Double) -> Unit) {
    if (products.isEmpty()) {
        EmptyState(Icons.Default.Inventory2, "No hay productos que coincidan.")
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(products, key = { it.id }) { product ->
            var qty by remember(product.id, selected[product.id]) { mutableDoubleStateOf(selected[product.id] ?: 0.0) }
            val isSelected = qty > 0
            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                )
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                            Text("SKU: ${product.sku}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (product.description.isNotBlank()) {
                                Text(product.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        StockBadge(product.stock, product.unit)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        FilledTonalIconButton(onClick = { qty = (qty - 1).coerceAtLeast(0.0); onQtyChange(product.id, qty) }) {
                            Icon(Icons.Default.Remove, null)
                        }
                        Text(
                            formatQty(qty),
                            modifier = Modifier.padding(horizontal = 16.dp),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        FilledTonalIconButton(onClick = { qty += 1; onQtyChange(product.id, qty) }) {
                            Icon(Icons.Default.Add, null)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
private fun RequestList(requests: List<StockRequest>) {
    if (requests.isEmpty()) {
        EmptyState(Icons.Default.Send, "No has enviado pedidos todavía.")
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(requests, key = { it.id }) { request ->
            ElevatedCard(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Pedido #${request.id.take(6).uppercase()}", fontWeight = FontWeight.Bold)
                        StatusBadge(request.status)
                    }
                    Text(formatDate(request.createdAtMillis), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(8.dp))
                    request.items.forEach {
                        Text("• ${formatQty(it.quantity)} ${it.unit} — ${it.name}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun WarehouseScreen(repo: FirebaseRepository, user: AppUser, onLogout: () -> Unit) {
    var requests by remember { mutableStateOf<List<StockRequest>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        val r1 = repo.listenPendingRequests({ requests = it }, { error = it.message })
        val r2 = repo.listenProducts({ products = it }, { error = it.message })
        onDispose { r1.remove(); r2.remove() }
    }

    val pendingCount = requests.count { it.status == RequestStatus.PENDING }
    val filteredProducts = if (query.isBlank()) {
        products
    } else {
        products.filter { it.name.contains(query, ignoreCase = true) || it.sku.contains(query, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Hola, ${user.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Almacén", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, contentDescription = "Salir") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = {
                        BadgedBox(badge = { if (pendingCount > 0) Badge { Text("$pendingCount") } }) {
                            Icon(Icons.Default.Send, null)
                        }
                    },
                    label = { Text("Pedidos") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Inventory2, null) },
                    label = { Text("Productos") }
                )
            }
        },
        floatingActionButton = {
            if (tab == 1) {
                FloatingActionButton(onClick = { showForm = true }) { Icon(Icons.Default.Add, null) }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
            if (tab == 0) {
                WarehouseRequests(repo, requests)
            } else {
                SearchField(query) { query = it }
                ProductAdmin(filteredProducts)
            }
        }
    }
    if (showForm) AddProductDialog(repo) { showForm = false }
}

@Composable
private fun WarehouseRequests(repo: FirebaseRepository, requests: List<StockRequest>) {
    if (requests.isEmpty()) {
        EmptyState(Icons.Default.Send, "No hay pedidos pendientes.")
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(requests, key = { it.id }) { request ->
            ElevatedCard(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(request.storeName, fontWeight = FontWeight.Bold)
                            Text(
                                "#${request.id.take(6).uppercase()} · ${formatDate(request.createdAtMillis)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusBadge(request.status)
                    }
                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(8.dp))
                    request.items.forEach {
                        Text("• ${formatQty(it.quantity)} ${it.unit} — ${it.name}", style = MaterialTheme.typography.bodyMedium)
                    }
                    if (request.status == RequestStatus.PENDING || request.status == RequestStatus.PREPARING) {
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (request.status == RequestStatus.PENDING) {
                                OutlinedButton(
                                    onClick = { repo.updateRequestStatus(request.id, RequestStatus.REJECTED) {} },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Rechazar") }
                                Button(
                                    onClick = { repo.updateRequestStatus(request.id, RequestStatus.PREPARING) {} },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Preparar") }
                            } else {
                                Button(
                                    onClick = { repo.updateRequestStatus(request.id, RequestStatus.READY) {} },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Marcar listo") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductAdmin(products: List<Product>) {
    if (products.isEmpty()) {
        EmptyState(Icons.Default.Inventory2, "Todavía no hay productos cargados.")
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(products, key = { it.id }) { product ->
            ElevatedCard(shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.secondaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Inventory2, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(product.name, fontWeight = FontWeight.Bold)
                        Text(product.sku, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    StockBadge(product.stock, product.unit)
                }
            }
        }
    }
}

@Composable
private fun AddProductDialog(repo: FirebaseRepository, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var sku by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("unidad") }
    var stock by remember { mutableStateOf("0") }
    var busy by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Nuevo producto") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(sku, { sku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(description, { description = it }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(unit, { unit = it }, label = { Text("Unidad") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        stock, { stock = it }, label = { Text("Stock") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(enabled = !busy && name.isNotBlank(), onClick = {
                busy = true
                repo.addProduct(name, sku, description, unit, stock.toDoubleOrNull() ?: 0.0) { result ->
                    busy = false
                    if (result.isSuccess) onDismiss()
                }
            }) {
                if (busy) CircularProgressIndicator(Modifier.size(20.dp)) else Text("Guardar")
            }
        },
        dismissButton = { OutlinedButton(enabled = !busy, onClick = onDismiss) { Text("Cancelar") } }
    )
}

private fun formatQty(value: Double): String =
    if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.2f", value)

private fun formatDate(millis: Long): String =
    if (millis == 0L) "Ahora" else SimpleDateFormat("dd/MM HH:mm", Locale("es", "PE")).format(Date(millis))
