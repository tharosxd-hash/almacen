# Solicitud Almacén — versión sin imágenes

Aplicación Android para tiendas y almacén con Firebase Authentication + Cloud Firestore.

## Colecciones que usa esta versión

- `users`
- `productos`
- `requests`

## Roles

En `users/{UID}`:

- `role: "store"` para una tienda
- `role: "warehouse"` para el almacén

Campos mínimos:

- `name` (string)
- `role` (string)

El documento debe usar como ID el UID que aparece en Authentication.

## Productos

Colección `productos`:

- `name` string
- `sku` string
- `description` string
- `unit` string
- `stock` number/int64
- `active` boolean

## Pedidos

Colección `requests`. La aplicación los crea automáticamente cuando una tienda envía una solicitud.

## Firebase

1. Authentication → Método de acceso → Correo electrónico/contraseña: ACTIVADO.
2. Firestore Database: creado.
3. Storage NO es necesario en esta versión.
4. Copiar `google-services.json` dentro de `app/`.
5. Publicar las reglas incluidas en `firestore.rules` en Firestore → Reglas.

## Importante

El proyecto está preparado para usar `productos`, no `products`.
