package com.solicitudalmacen

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.AssistChip
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.firestore.ListenerRegistration
import com.solicitudalmacen.data.AppUser
import com.solicitudalmacen.data.FirebaseRepository
import com.solicitudalmacen.data.Product
import com.solicitudalmacen.data.RequestItem
import com.solicitudalmacen.data.RequestStatus
import com.solicitudalmacen.data.StockRequest
import com.solicitudalmacen.data.UserRole
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
private fun App() {
    val repo = remember { FirebaseRepository() }
    var user by remember { mutableStateOf<AppUser?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        repo.loadCurrentUser { result ->
            loading = false
            result.onSuccess { user = it }.onFailure { error = it.message }
        }
    }

    MaterialTheme {
        when {
            loading -> CenterLoading()
            user == null -> LoginScreen(repo, initialError = error) {
                user = it
                error = null
            }
            user!!.role == UserRole.STORE -> StoreScreen(repo, user!!) {
                repo.logout(); user = null
            }
            else -> WarehouseScreen(repo, user!!) {
                repo.logout(); user = null
            }
        }
    }
}

@Composable
private fun CenterLoading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

@Composable
private fun LoginScreen(repo: FirebaseRepository, initialError: String?, onLoggedIn: (AppUser) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(initialError ?: "") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text("Pedidos Almacén", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Ingresa con tu cuenta de tienda o almacén")
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            password, { password = it }, label = { Text("Contraseña") }, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp)); Text(error, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                busy = true
                repo.login(email, password) { result ->
                    busy = false
                    result.onSuccess(onLoggedIn).onFailure { error = it.message ?: "No se pudo iniciar sesión" }
                }
            },
            enabled = !busy && email.isNotBlank() && password.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { if (busy) CircularProgressIndicator(modifier = Modifier.size(22.dp)) else Text("Entrar") }
    }
}

@Composable
private fun StoreScreen(repo: FirebaseRepository, user: AppUser, onLogout: () -> Unit) {
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var requests by remember { mutableStateOf<List<StockRequest>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Map<String, Double>>(emptyMap()) }
    var tab by remember { mutableIntStateOf(0) }

    DisposableEffect(user.uid) {
        val productListener = repo.listenProducts({ products = it }, { error = it.message })
        val requestListener = repo.listenRequestsForStore(user.uid, { requests = it }, { error = it.message })
        onDispose { productListener.remove(); requestListener.remove() }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Tienda · ${user.name}") }, actions = {
            IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, contentDescription = "Salir") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { tab = 0 }, label = { Text("Productos") }, leadingIcon = { Icon(Icons.Default.Storefront, null) })
                AssistChip(onClick = { tab = 1 }, label = { Text("Mis pedidos (${requests.size})") }, leadingIcon = { Icon(Icons.Default.Send, null) })
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
            if (tab == 0) {
                StoreProductList(products, selected) { id, qty ->
                    selected = selected.toMutableMap().apply { if (qty <= 0) remove(id) else put(id, qty) }
                }
                val itemsToSend = products.filter { (selected[it.id] ?: 0.0) > 0 }.map {
                    RequestItem(it.id, it.name, it.sku, it.unit, selected[it.id] ?: 0.0)
                }
                if (itemsToSend.isNotEmpty()) {
                    Card(Modifier.fillMaxWidth().padding(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${itemsToSend.size} productos en el pedido", fontWeight = FontWeight.SemiBold)
                            Button(onClick = {
                                repo.sendRequest(user, itemsToSend) { result ->
                                    result.onSuccess { selected = emptyMap(); tab = 1 }
                                        .onFailure { error = it.message }
                                }
                            }) { Text("Enviar") }
                        }
                    }
                }
            } else {
                RequestList(requests)
            }
        }
    }
}

@Composable
private fun StoreProductList(products: List<Product>, selected: Map<String, Double>, onQtyChange: (String, Double) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (products.isEmpty()) item { Text("Todavía no hay productos cargados.") }
        items(products, key = { it.id }) { product ->
            var qty by remember(product.id, selected[product.id]) { mutableDoubleStateOf(selected[product.id] ?: 0.0) }
            ElevatedCard {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.Bold)
                            Text("SKU: ${product.sku}")
                            if (product.description.isNotBlank()) Text(product.description, style = MaterialTheme.typography.bodySmall)
                            Text("Stock informado: ${formatQty(product.stock)} ${product.unit}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        IconButton(onClick = { qty = (qty - 1).coerceAtLeast(0.0); onQtyChange(product.id, qty) }) { Icon(Icons.Default.Remove, null) }
                        Text(formatQty(qty), modifier = Modifier.padding(horizontal = 12.dp), fontWeight = FontWeight.Bold)
                        IconButton(onClick = { qty += 1; onQtyChange(product.id, qty) }) { Icon(Icons.Default.Add, null) }
                    }
                }
            }
        }
    }
}

@Composable
private fun RequestList(requests: List<StockRequest>) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (requests.isEmpty()) item { Text("No has enviado pedidos todavía.") }
        items(requests, key = { it.id }) { request ->
            ElevatedCard {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pedido #${request.id.take(6).uppercase()}", fontWeight = FontWeight.Bold)
                        StatusChip(request.status)
                    }
                    Text(formatDate(request.createdAtMillis), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(6.dp))
                    request.items.forEach { Text("• ${formatQty(it.quantity)} ${it.unit} — ${it.name}") }
                }
            }
        }
    }
}

@Composable
private fun WarehouseScreen(repo: FirebaseRepository, user: AppUser, onLogout: () -> Unit) {
    var requests by remember { mutableStateOf<List<StockRequest>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        val r1 = repo.listenPendingRequests({ requests = it }, { error = it.message })
        val r2 = repo.listenProducts({ products = it }, { error = it.message })
        onDispose { r1.remove(); r2.remove() }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Almacén · ${user.name}") }, actions = {
            IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, contentDescription = "Salir") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { tab = 0 }, label = { Text("Pedidos (${requests.size})") }, leadingIcon = { Icon(Icons.Default.Send, null) })
                AssistChip(onClick = { tab = 1 }, label = { Text("Productos (${products.size})") }, leadingIcon = { Icon(Icons.Default.Inventory2, null) })
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
            if (tab == 0) WarehouseRequests(repo, requests) else ProductAdmin(repo, products)
        }
    }
}

@Composable
private fun WarehouseRequests(repo: FirebaseRepository, requests: List<StockRequest>) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (requests.isEmpty()) item { Text("No hay pedidos pendientes.") }
        items(requests, key = { it.id }) { request ->
            ElevatedCard {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(request.storeName, fontWeight = FontWeight.Bold)
                            Text("#${request.id.take(6).uppercase()} · ${formatDate(request.createdAtMillis)}", style = MaterialTheme.typography.bodySmall)
                        }
                        StatusChip(request.status)
                    }
                    Spacer(Modifier.height(8.dp))
                    request.items.forEach { Text("• ${formatQty(it.quantity)} ${it.unit} — ${it.name}") }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (request.status == RequestStatus.PENDING) {
                            OutlinedButton(onClick = { repo.updateRequestStatus(request.id, RequestStatus.REJECTED) {} }) { Text("Rechazar") }
                            Button(onClick = { repo.updateRequestStatus(request.id, RequestStatus.PREPARING) {} }) { Text("Preparar") }
                        } else if (request.status == RequestStatus.PREPARING) {
                            Button(onClick = { repo.updateRequestStatus(request.id, RequestStatus.READY) {} }) { Text("Marcar listo") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductAdmin(repo: FirebaseRepository, products: List<Product>) {
    var showForm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.End) {
            Button(onClick = { showForm = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.size(6.dp)); Text("Nuevo producto") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products, key = { it.id }) { product ->
                ElevatedCard {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.size(10.dp))
                        Column {
                            Text(product.name, fontWeight = FontWeight.Bold)
                            Text("${product.sku} · ${formatQty(product.stock)} ${product.unit}")
                        }
                    }
                }
            }
        }
    }
    if (showForm) AddProductDialog(repo) { showForm = false }
}

@Composable
private fun AddProductDialog(repo: FirebaseRepository, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var sku by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("unidad") }
    var stock by remember { mutableStateOf("0") }
    var busy by remember { mutableStateOf(false) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Nuevo producto") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") })
                OutlinedTextField(sku, { sku = it }, label = { Text("SKU") })
                OutlinedTextField(description, { description = it }, label = { Text("Descripción") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(unit, { unit = it }, label = { Text("Unidad") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(stock, { stock = it }, label = { Text("Stock") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            }
        },
        confirmButton = {
            Button(enabled = !busy && name.isNotBlank(), onClick = {
                busy = true
                repo.addProduct(name, sku, description, unit, stock.toDoubleOrNull() ?: 0.0) { result ->
                    busy = false
                    if (result.isSuccess) onDismiss()
                }
            }) { if (busy) CircularProgressIndicator(Modifier.size(20.dp)) else Text("Guardar") }
        },
        dismissButton = { OutlinedButton(enabled = !busy, onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun StatusChip(status: RequestStatus) {
    val text = when (status) {
        RequestStatus.PENDING -> "Pendiente"
        RequestStatus.PREPARING -> "Preparando"
        RequestStatus.READY -> "Listo"
        RequestStatus.REJECTED -> "Rechazado"
    }
    AssistChip(onClick = {}, label = { Text(text) })
}

private fun formatQty(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.2f", value)
private fun formatDate(millis: Long): String = if (millis == 0L) "Ahora" else SimpleDateFormat("dd/MM HH:mm", Locale("es", "PE")).format(Date(millis))
