package com.solicitudalmacen.data

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class FirebaseRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun currentUser() = auth.currentUser

    fun login(email: String, password: String, onResult: (Result<AppUser>) -> Unit) {
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener {
                loadCurrentUser(onResult)
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun logout() = auth.signOut()

    fun loadCurrentUser(onResult: (Result<AppUser>) -> Unit) {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            onResult(Result.failure(IllegalStateException("No hay sesión")))
            return
        }
        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) {
                    onResult(Result.failure(IllegalStateException("Falta el documento users/$uid")))
                    return@addOnSuccessListener
                }
                val role = runCatching { UserRole.valueOf((doc.getString("role") ?: "STORE").uppercase()) }
                    .getOrDefault(UserRole.STORE)
                onResult(Result.success(
                    AppUser(
                        uid = uid,
                        name = doc.getString("name") ?: "Usuario",
                        role = role,
                        storeId = doc.getString("storeId") ?: uid
                    )
                ))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun listenProducts(onChange: (List<Product>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("productos")
            .whereEqualTo("active", true)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                onChange(snapshot?.documents.orEmpty().mapNotNull { it.toProduct() }.sortedBy { it.name.lowercase() })
            }
    }

    fun listenRequestsForStore(storeId: String, onChange: (List<StockRequest>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("requests")
            .whereEqualTo("storeId", storeId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                onChange(snapshot?.documents.orEmpty().mapNotNull { it.toRequest() }.sortedByDescending { it.createdAtMillis })
            }
    }

    fun listenPendingRequests(onChange: (List<StockRequest>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("requests")
            .whereIn("status", listOf("PENDING", "PREPARING"))
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                onChange(snapshot?.documents.orEmpty().mapNotNull { it.toRequest() }.sortedByDescending { it.createdAtMillis })
            }
    }

    fun sendRequest(user: AppUser, items: List<RequestItem>, onResult: (Result<Unit>) -> Unit) {
        val requestItems = items.map {
            mapOf(
                "productId" to it.productId,
                "name" to it.name,
                "sku" to it.sku,
                "unit" to it.unit,
                "quantity" to it.quantity
            )
        }
        val data = mapOf(
            "storeId" to user.uid,
            "storeName" to user.name,
            "items" to requestItems,
            "status" to RequestStatus.PENDING.name,
            "createdAt" to FieldValue.serverTimestamp()
        )
        db.collection("requests").add(data)
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun updateRequestStatus(requestId: String, status: RequestStatus, onResult: (Result<Unit>) -> Unit) {
        db.collection("requests").document(requestId)
            .update(
                mapOf(
                    "status" to status.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun addProduct(
        name: String,
        sku: String,
        description: String,
        unit: String,
        stock: Double,
        onResult: (Result<Unit>) -> Unit
    ) {
        val data = mapOf(
            "name" to name.trim(),
            "sku" to sku.trim(),
            "description" to description.trim(),
            "unit" to unit.trim().ifBlank { "unidad" },
            "stock" to stock,
            "active" to true,
            "createdAt" to FieldValue.serverTimestamp()
        )
        db.collection("productos").add(data)
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }
}
