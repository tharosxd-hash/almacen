package com.solicitudalmacen.data

import com.google.firebase.firestore.DocumentSnapshot


enum class UserRole { STORE, WAREHOUSE }

enum class RequestStatus { PENDING, PREPARING, READY, REJECTED }

data class AppUser(
    val uid: String,
    val name: String,
    val role: UserRole,
    val storeId: String = ""
)

data class Product(
    val id: String,
    val name: String,
    val sku: String,
    val description: String,
    val unit: String,
    val stock: Double,
    val imageUrl: String,
    val active: Boolean = true
)

data class RequestItem(
    val productId: String,
    val name: String,
    val sku: String,
    val unit: String,
    val quantity: Double
)

data class StockRequest(
    val id: String,
    val storeId: String,
    val storeName: String,
    val items: List<RequestItem>,
    val status: RequestStatus,
    val createdAtMillis: Long
)

fun DocumentSnapshot.toProduct(): Product? {
    return Product(
        id = id,
        name = getString("name") ?: return null,
        sku = getString("sku") ?: "",
        description = getString("description") ?: "",
        unit = getString("unit") ?: "unidad",
        stock = (get("stock") as? Number)?.toDouble() ?: 0.0,
        imageUrl = getString("imageUrl") ?: "",
        active = getBoolean("active") ?: true
    )
}

fun DocumentSnapshot.toRequest(): StockRequest? {
    val rawItems = get("items") as? List<*> ?: return null
    val items = rawItems.mapNotNull { raw ->
        val map = raw as? Map<*, *> ?: return@mapNotNull null
        RequestItem(
            productId = map["productId"]?.toString() ?: return@mapNotNull null,
            name = map["name"]?.toString() ?: "",
            sku = map["sku"]?.toString() ?: "",
            unit = map["unit"]?.toString() ?: "unidad",
            quantity = (map["quantity"] as? Number)?.toDouble() ?: 0.0
        )
    }
    val status = runCatching {
        RequestStatus.valueOf((getString("status") ?: "PENDING").uppercase())
    }.getOrDefault(RequestStatus.PENDING)
    val created = getTimestamp("createdAt")?.toDate()?.time ?: 0L
    return StockRequest(
        id = id,
        storeId = getString("storeId") ?: "",
        storeName = getString("storeName") ?: "Tienda",
        items = items,
        status = status,
        createdAtMillis = created
    )
}
