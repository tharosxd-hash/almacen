# Solicitud Almacén

Aplicación Android para solicitudes de mercancía entre tiendas y almacén con Firebase Authentication y Cloud Firestore.

## Esquema de Firestore que usa esta versión

### `users/{UID}`
Cada documento debe usar como ID el UID exacto de Firebase Authentication.

- `name` (string): nombre visible de la persona/tienda.
- `role` (string): `warehouse` para almacén o `store` para una tienda.
- `storeId` (string, opcional): actualmente las solicitudes se guardan con el UID de la cuenta como `storeId`.

Crea/edita estos documentos desde Firebase Console. Las reglas impiden que la aplicación cambie los roles.

### `productos/{ID_AUTOMÁTICO}`
- `tipoProducto` (string), ejemplo `Parlante`
- `marca` (string), ejemplo `JBL`
- `modelo` (string), ejemplo `Flip 6`
- `stock` (number), ejemplo `10`

La aplicación crea, lee, edita y elimina productos desde la pantalla de almacén. Las tiendas solo pueden leer el inventario.

### `requests/{ID_AUTOMÁTICO}`
Las tiendas crean solicitudes con `storeId` igual al UID de su cuenta, `storeName`, `items` (lista), `status` (`PENDING`) y `createdAt`. Almacén puede consultar y actualizar su estado.

## Reglas de Firebase

El archivo `firestore.rules` contiene las reglas para publicar en Firebase Console → Firestore Database → Reglas. Publicarlas es una acción separada de compilar el APK.

## Compilar en GitHub

El workflow está en `.github/workflows/compilar-apk.yml`. Sube el contenido del ZIP a la raíz del repositorio (no el ZIP comprimido dentro del repositorio), confirma los cambios en la rama `main` y abre Actions → Compilar APK → Run workflow. El APK se publica como artefacto `Solicitud-Almacen-APK`.

## Importante

El archivo `app/google-services.json` está ligado al proyecto Firebase `almacen-7f442` y al paquete `com.solicitudalmacen`. No lo sustituyas por el de otro proyecto.
