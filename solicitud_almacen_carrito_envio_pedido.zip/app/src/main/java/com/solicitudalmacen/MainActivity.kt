package com.solicitudalmacen

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.AssistChip
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.firestore.ListenerRegistration
import com.solicitudalmacen.data.AppUser
import com.solicitudalmacen.data.FirebaseRepository
import com.solicitudalmacen.data.Product
import com.solicitudalmacen.data.RequestItem
import com.solicitudalmacen.data.RequestStatus
import com.solicitudalmacen.data.StockRequest
import com.solicitudalmacen.data.UserRole
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
private fun App() {
    val repo = remember { FirebaseRepository() }
    var user by remember { mutableStateOf<AppUser?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var darkMode by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        repo.loadCurrentUser { result ->
            loading = false
            result.onSuccess { user = it }.onFailure { error = it.message }
        }
    }

    val colors = if (darkMode) androidx.compose.material3.darkColorScheme() else androidx.compose.material3.lightColorScheme()
    MaterialTheme(colorScheme = colors) {
        when {
            loading -> CenterLoading()
            user == null -> LoginScreen(repo, initialError = error, darkMode = darkMode, onToggleDark = { darkMode = !darkMode }) {
                user = it
                error = null
            }
            user!!.role == UserRole.STORE -> StoreScreen(repo, user!!, darkMode, { darkMode = !darkMode }) {
                repo.logout(); user = null
            }
            else -> WarehouseScreen(repo, user!!, darkMode, { darkMode = !darkMode }) {
                repo.logout(); user = null
            }
        }
    }
}

@Composable
private fun CenterLoading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

@Composable
private fun LoginScreen(repo: FirebaseRepository, initialError: String?, darkMode: Boolean, onToggleDark: () -> Unit, onLoggedIn: (AppUser) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(initialError ?: "") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { IconButton(onClick = onToggleDark) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Cambiar tema") } }
        Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text("Pedidos Almacén", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Ingresa con tu cuenta de tienda o almacén")
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Correo") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            password, { password = it }, label = { Text("Contraseña") }, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp)); Text(error, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                busy = true
                repo.login(email, password) { result ->
                    busy = false
                    result.onSuccess(onLoggedIn).onFailure { error = it.message ?: "No se pudo iniciar sesión" }
                }
            },
            enabled = !busy && email.isNotBlank() && password.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { if (busy) CircularProgressIndicator(modifier = Modifier.size(22.dp)) else Text("Entrar") }
    }
}

@Composable
private fun StoreScreen(repo: FirebaseRepository, user: AppUser, darkMode: Boolean, onToggleDark: () -> Unit, onLogout: () -> Unit) {
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var requests by remember { mutableStateOf<List<StockRequest>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Map<String, Double>>(emptyMap()) }
    var tab by remember { mutableIntStateOf(0) }
    var sending by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("Todas") }

    DisposableEffect(user.uid) {
        val productListener = repo.listenProducts({ products = it }, { error = it.message ?: "No se pudieron cargar los productos" })
        val requestListener = repo.listenRequestsForStore(user.uid, { requests = it }, { error = it.message ?: "No se pudieron cargar los pedidos" })
        onDispose { productListener.remove(); requestListener.remove() }
    }

    val cartProducts = products.filter { (selected[it.id] ?: 0.0) > 0 && it.active }
    val itemsToSend = cartProducts.map { product ->
        RequestItem(product.id, product.name, product.sku, product.unit, selected[product.id] ?: 0.0)
    }

    fun sendCart() {
        if (sending) return
        if (itemsToSend.isEmpty()) {
            error = "El carrito está vacío. Selecciona cantidades antes de enviar."
            return
        }
        sending = true
        error = null
        repo.sendRequest(user, itemsToSend) { result ->
            sending = false
            result.onSuccess {
                selected = emptyMap()
                tab = 2
                error = null
            }.onFailure {
                error = "No se pudo enviar el pedido: ${it.message ?: "comprueba la conexión y las reglas de Firebase"}"
            }
        }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Tienda · ${user.name}") }, actions = {
            IconButton(onClick = onToggleDark) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Cambiar tema") }
            IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, contentDescription = "Salir") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip(onClick = { tab = 0 }, label = { Text("Productos") }, leadingIcon = { Icon(Icons.Default.Storefront, null) })
                AssistChip(onClick = { tab = 1 }, label = { Text("🛒 Carrito (${itemsToSend.size})") })
                AssistChip(onClick = { tab = 2 }, label = { Text("Pedidos (${requests.size})") }, leadingIcon = { Icon(Icons.Default.Send, null) })
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
            when (tab) {
                0 -> {
                    val categories = listOf("Todas") + products.filter { it.active }.map { it.category }.distinct().sorted()
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(categories) { category ->
                            AssistChip(onClick = { selectedCategory = category }, label = { Text(category) })
                        }
                    }
                    StoreProductList(
                        products.filter { it.active && (selectedCategory == "Todas" || it.category == selectedCategory) },
                        selected,
                        modifier = Modifier.weight(1f)
                    ) { id, qty ->
                        selected = selected.toMutableMap().apply { if (qty <= 0) remove(id) else put(id, qty) }
                    }
                    if (itemsToSend.isNotEmpty()) {
                        Card(Modifier.fillMaxWidth().padding(10.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${itemsToSend.size} productos en el carrito", fontWeight = FontWeight.SemiBold)
                                    Text("Revisa y confirma el pedido")
                                }
                                Button(onClick = { tab = 1 }) { Text("Ver carrito") }
                            }
                        }
                    }
                }
                1 -> CartScreen(
                    products = cartProducts,
                    selected = selected,
                    sending = sending,
                    onQtyChange = { id, qty -> selected = selected.toMutableMap().apply { if (qty <= 0) remove(id) else put(id, qty) } },
                    onRemove = { id -> selected = selected.toMutableMap().apply { remove(id) } },
                    onSend = { sendCart() }
                )
                else -> RequestList(requests, onCancel = { id ->
                    repo.cancelStoreRequest(id) { result ->
                        result.onFailure { error = it.message ?: "No se pudo cancelar el pedido" }
                    }
                })
            }
        }
    }
}

@Composable
private fun CartScreen(
    products: List<Product>,
    selected: Map<String, Double>,
    sending: Boolean,
    onQtyChange: (String, Double) -> Unit,
    onRemove: (String) -> Unit,
    onSend: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        if (products.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Tu carrito está vacío", style = MaterialTheme.typography.titleLarge)
                    Text("Ve a Productos y usa + para añadir mercadería.")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(products, key = { it.id }) { product ->
                    val quantity = selected[product.id] ?: 0.0
                    ElevatedCard {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(product.name, fontWeight = FontWeight.Bold)
                                Text("${formatQty(quantity)} ${product.unit}")
                            }
                            IconButton(onClick = { onQtyChange(product.id, quantity - 1) }, enabled = !sending) { Icon(Icons.Default.Remove, contentDescription = "Reducir cantidad") }
                            IconButton(onClick = { onQtyChange(product.id, quantity + 1) }, enabled = !sending) { Icon(Icons.Default.Add, contentDescription = "Aumentar cantidad") }
                            IconButton(onClick = { onRemove(product.id) }, enabled = !sending) { Icon(Icons.Default.Delete, contentDescription = "Quitar del carrito") }
                        }
                    }
                }
            }
            Card(Modifier.fillMaxWidth().padding(12.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Pedido: ${products.size} productos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Al enviar, el pedido aparecerá en tiempo real en la pantalla de almacén.")
                    Button(onClick = onSend, enabled = !sending && products.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                        if (sending) CircularProgressIndicator(Modifier.size(20.dp)) else Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(Modifier.size(8.dp))
                        Text(if (sending) "Enviando pedido…" else "ENVIAR PEDIDO A ALMACÉN")
                    }
                }
            }
        }
    }
}

@Composable
private fun RequestList(requests: List<StockRequest>, onCancel: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (requests.isEmpty()) item { Text("No has enviado pedidos todavía.") }
        items(requests, key = { it.id }) { request ->
            ElevatedCard {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pedido #${request.id.take(6).uppercase()}", fontWeight = FontWeight.Bold)
                        StatusChip(request.status)
                    }
                    Text(formatDate(request.createdAtMillis), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(6.dp))
                    request.items.forEach { Text("• ${formatQty(it.quantity)} ${it.unit} — ${it.name}") }
                    if (request.status == RequestStatus.PENDING) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { onCancel(request.id) }) { Text("Cancelar pedido") }
                    }
                }
            }
        }
    }
}

@Composable
private fun WarehouseScreen(repo: FirebaseRepository, user: AppUser, darkMode: Boolean, onToggleDark: () -> Unit, onLogout: () -> Unit) {
    var requests by remember { mutableStateOf<List<StockRequest>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        val r1 = repo.listenPendingRequests({ requests = it }, { error = it.message })
        val r2 = repo.listenProducts({ products = it }, { error = it.message })
        onDispose { r1.remove(); r2.remove() }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Almacén · ${user.name}") }, actions = {
            IconButton(onClick = onToggleDark) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Cambiar tema") }
            IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, contentDescription = "Salir") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { tab = 0 }, label = { Text("Pedidos (${requests.size})") }, leadingIcon = { Icon(Icons.Default.Send, null) })
                AssistChip(onClick = { tab = 1 }, label = { Text("Productos (${products.size})") }, leadingIcon = { Icon(Icons.Default.Inventory2, null) })
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
            if (tab == 0) WarehouseRequests(repo, requests) else ProductAdmin(repo, products)
        }
    }
}

@Composable
private fun WarehouseRequests(repo: FirebaseRepository, requests: List<StockRequest>) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (requests.isEmpty()) item { Text("No hay pedidos pendientes.") }
        items(requests, key = { it.id }) { request ->
            ElevatedCard {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(request.storeName, fontWeight = FontWeight.Bold)
                            Text("#${request.id.take(6).uppercase()} · ${formatDate(request.createdAtMillis)}", style = MaterialTheme.typography.bodySmall)
                        }
                        StatusChip(request.status)
                    }
                    Spacer(Modifier.height(8.dp))
                    request.items.forEach { Text("• ${formatQty(it.quantity)} ${it.unit} — ${it.name}") }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (request.status == RequestStatus.PENDING) {
                            OutlinedButton(onClick = { repo.updateRequestStatus(request.id, RequestStatus.REJECTED) { result -> result.onFailure { } } }) { Text("Rechazar") }
                            Button(onClick = { repo.updateRequestStatus(request.id, RequestStatus.PREPARING) { result -> result.onFailure { } } }) { Text("Aceptar pedido") }
                        } else if (request.status == RequestStatus.PREPARING) {
                            Button(onClick = { repo.updateRequestStatus(request.id, RequestStatus.READY) {} }) { Text("Marcar listo") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductAdmin(repo: FirebaseRepository, products: List<Product>) {
    var showForm by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var deletingProduct by remember { mutableStateOf<Product?>(null) }
    var adminError by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.End) {
            Button(onClick = { showForm = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.size(6.dp)); Text("Nuevo producto") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products, key = { it.id }) { product ->
                ElevatedCard {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.Bold)
                            Text("${product.sku} · ${formatQty(product.stock)} ${product.unit}")
                            Text("Categoría: ${product.category}", style = MaterialTheme.typography.bodySmall)
                            if (product.description.isNotBlank()) Text(product.description, style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { editingProduct = product }) { Icon(Icons.Default.Edit, contentDescription = "Editar mercadería") }
                        IconButton(onClick = { deletingProduct = product }) { Icon(Icons.Default.Delete, contentDescription = "Eliminar producto") }
                    }
                }
            }
        }
    }
    adminError?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
    if (showForm) AddProductDialog(repo) { showForm = false }
    deletingProduct?.let { product ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { deletingProduct = null },
            title = { Text("Eliminar producto") },
            text = { Text("¿Eliminar ${product.name}? Esta acción no se puede deshacer.") },
            confirmButton = { Button(onClick = { repo.deleteProduct(product.id) { result -> result.onSuccess { deletingProduct = null }.onFailure { adminError = it.message ?: "No se pudo eliminar"; deletingProduct = null } } }) { Text("Eliminar") } },
            dismissButton = { OutlinedButton(onClick = { deletingProduct = null }) { Text("Cancelar") } }
        )
    }
    editingProduct?.let { product -> EditProductDialog(repo, product) { editingProduct = null } }
}

@Composable
private fun AddProductDialog(repo: FirebaseRepository, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var sku by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }
    var unit by remember { mutableStateOf("unidad") }
    var stock by remember { mutableStateOf("0") }
    var busy by remember { mutableStateOf(false) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Nuevo producto") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") })
                OutlinedTextField(sku, { sku = it }, label = { Text("SKU") })
                OutlinedTextField(description, { description = it }, label = { Text("Descripción") })
                OutlinedTextField(category, { category = it }, label = { Text("Categoría") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(unit, { unit = it }, label = { Text("Unidad") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(stock, { stock = it }, label = { Text("Stock") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            }
        },
        confirmButton = {
            Button(enabled = !busy && name.isNotBlank(), onClick = {
                busy = true
                repo.addProduct(name, sku, description, category, unit, stock.toDoubleOrNull() ?: 0.0) { result ->
                    busy = false
                    if (result.isSuccess) onDismiss()
                }
            }) { if (busy) CircularProgressIndicator(Modifier.size(20.dp)) else Text("Guardar") }
        },
        dismissButton = { OutlinedButton(enabled = !busy, onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun EditProductDialog(repo: FirebaseRepository, product: Product, onDismiss: () -> Unit) {
    var name by remember(product.id) { mutableStateOf(product.name) }
    var sku by remember(product.id) { mutableStateOf(product.sku) }
    var description by remember(product.id) { mutableStateOf(product.description) }
    var category by remember(product.id) { mutableStateOf(product.category) }
    var unit by remember(product.id) { mutableStateOf(product.unit) }
    var stock by remember(product.id) { mutableStateOf(formatQty(product.stock)) }
    var active by remember(product.id) { mutableStateOf(product.active) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Editar mercadería") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") })
                OutlinedTextField(sku, { sku = it }, label = { Text("SKU") })
                OutlinedTextField(description, { description = it }, label = { Text("Descripción") })
                OutlinedTextField(category, { category = it }, label = { Text("Categoría") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(unit, { unit = it }, label = { Text("Unidad") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(stock, { stock = it }, label = { Text("Stock") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Checkbox(checked = active, onCheckedChange = { active = it })
                    Text("Producto activo y visible para tiendas")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && name.isNotBlank() && (stock.toDoubleOrNull() ?: -1.0) >= 0.0, onClick = {
                busy = true
                repo.updateProduct(product.id, name, sku, description, category, unit, stock.toDoubleOrNull() ?: 0.0, active) { result ->
                    busy = false
                    result.onSuccess { onDismiss() }.onFailure { error = it.message ?: "No se pudo guardar" }
                }
            }) { if (busy) CircularProgressIndicator(Modifier.size(20.dp)) else Text("Guardar cambios") }
        },
        dismissButton = { OutlinedButton(enabled = !busy, onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun StatusChip(status: RequestStatus) {
    val text = when (status) {
        RequestStatus.PENDING -> "Pendiente"
        RequestStatus.PREPARING -> "Preparando"
        RequestStatus.READY -> "Listo"
        RequestStatus.REJECTED -> "Rechazado"
    }
    AssistChip(onClick = {}, label = { Text(text) })
}

private fun formatQty(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.2f", value)
private fun formatDate(millis: Long): String = if (millis == 0L) "Ahora" else SimpleDateFormat("dd/MM HH:mm", Locale("es", "PE")).format(Date(millis))
