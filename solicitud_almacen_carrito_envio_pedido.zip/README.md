# Solicitud Almacén

Aplicación Android para solicitudes de productos entre tiendas y almacén usando Firebase Authentication (correo/contraseña) y Cloud Firestore.

## Requisitos de Firebase
- La app Android debe estar registrada con el paquete `com.solicitudalmacen`.
- `app/google-services.json` debe corresponder al proyecto Firebase correcto.
- Activar proveedor de autenticación Correo/contraseña.
- Crear las colecciones `users`, `productos` y `requests` con los campos descritos en la configuración del proyecto.
- Publicar las reglas de `firestore.rules` en Firebase.

## Compilación en GitHub Actions
Sube este ZIP a la raíz del repositorio con el nombre `solicitud_almacen_firebase_total_corregido.zip` y utiliza el workflow `compilar-apk.yml` proporcionado aparte. El artefacto se llamará `Solicitud-Almacen-APK`.
