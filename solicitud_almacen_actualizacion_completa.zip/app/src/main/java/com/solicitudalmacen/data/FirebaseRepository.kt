package com.solicitudalmacen.data

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class FirebaseRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun currentUser() = auth.currentUser

    fun login(email: String, password: String, onResult: (Result<AppUser>) -> Unit) {
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener {
                loadCurrentUser(onResult)
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun logout() = auth.signOut()

    fun loadCurrentUser(onResult: (Result<AppUser>) -> Unit) {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            onResult(Result.failure(IllegalStateException("No hay sesión")))
            return
        }
        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) {
                    onResult(Result.failure(IllegalStateException("Falta el documento users/$uid")))
                    return@addOnSuccessListener
                }
                val role = runCatching { UserRole.valueOf((doc.getString("role") ?: "STORE").uppercase()) }
                    .getOrDefault(UserRole.STORE)
                onResult(Result.success(
                    AppUser(
                        uid = uid,
                        name = doc.getString("name") ?: "Usuario",
                        role = role,
                        storeId = doc.getString("storeId") ?: uid
                    )
                ))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun listenProducts(onChange: (List<Product>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("productos")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                onChange(snapshot?.documents.orEmpty().mapNotNull { it.toProduct() }.sortedBy { it.name.lowercase() })
            }
    }

    fun listenRequestsForStore(storeId: String, onChange: (List<StockRequest>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("requests")
            .whereEqualTo("storeId", storeId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                onChange(snapshot?.documents.orEmpty().mapNotNull { it.toRequest() }.sortedByDescending { it.createdAtMillis })
            }
    }

    fun listenPendingRequests(onChange: (List<StockRequest>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("requests")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                onChange(snapshot?.documents.orEmpty().mapNotNull { it.toRequest() }.sortedByDescending { it.createdAtMillis })
            }
    }

    fun sendRequest(user: AppUser, items: List<RequestItem>, onResult: (Result<Unit>) -> Unit) {
        val requestItems = items.map {
            mapOf(
                "productId" to it.productId,
                "name" to it.name,
                "sku" to it.sku,
                "unit" to it.unit,
                "quantity" to it.quantity
            )
        }
        val data = mapOf(
            "storeId" to user.uid,
            "storeName" to user.name,
            "items" to requestItems,
            "status" to RequestStatus.PENDING.name,
            "createdAt" to FieldValue.serverTimestamp()
        )
        db.collection("requests").add(data)
            .addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun updateRequestStatus(requestId: String, status: RequestStatus, onResult: (Result<Unit>) -> Unit) {
        val ref = db.collection("requests").document(requestId)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            val oldStatus = snap.getString("status") ?: "PENDING"
            tx.update(ref, mapOf("status" to status.name, "updatedAt" to FieldValue.serverTimestamp()))
            val log = db.collection("audit_logs").document()
            tx.set(log, mapOf("action" to "REQUEST_STATUS", "targetId" to requestId, "detail" to "$oldStatus -> ${status.name}", "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp()))
            null
        }.addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun updateProduct(
        productId: String,
        name: String,
        sku: String,
        description: String,
        category: String,
        unit: String,
        stock: Double,
        active: Boolean,
        onResult: (Result<Unit>) -> Unit
    ) {
        val data = mapOf(
            "name" to name.trim(),
            "sku" to sku.trim(),
            "description" to description.trim(),
            "category" to category.trim().ifBlank { "Sin categoría" },
            "unit" to unit.trim().ifBlank { "unidad" },
            "stock" to stock,
            "active" to active,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val productRef = db.collection("productos").document(productId)
        db.runTransaction { tx ->
            val before = tx.get(productRef)
            val oldStock = (before.get("stock") as? Number)?.toDouble() ?: 0.0
            tx.update(productRef, data)
            val log = db.collection("movements").document()
            tx.set(log, mapOf("productId" to productId, "productName" to name.trim(), "type" to if (stock >= oldStock) "ADJUSTMENT_IN" else "ADJUSTMENT_OUT", "quantity" to kotlin.math.abs(stock-oldStock), "beforeStock" to oldStock, "afterStock" to stock, "note" to "Ajuste de inventario", "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp()))
            val audit = db.collection("audit_logs").document()
            tx.set(audit, mapOf("action" to "PRODUCT_UPDATE", "targetId" to productId, "detail" to "Producto actualizado", "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp()))
            null
        }.addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun addProduct(
        name: String,
        sku: String,
        description: String,
        category: String,
        unit: String,
        stock: Double,
        onResult: (Result<Unit>) -> Unit
    ) {
        val data = mapOf(
            "name" to name.trim(),
            "sku" to sku.trim(),
            "description" to description.trim(),
            "category" to category.trim().ifBlank { "Sin categoría" },
            "unit" to unit.trim().ifBlank { "unidad" },
            "stock" to stock,
            "active" to true,
            "createdAt" to FieldValue.serverTimestamp()
        )
        db.collection("productos").add(data)
            .addOnSuccessListener { product ->
                val log = mapOf("productId" to product.id, "productName" to name.trim(), "type" to "INITIAL_STOCK", "quantity" to stock, "beforeStock" to 0.0, "afterStock" to stock, "note" to "Alta de producto", "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp())
                db.collection("movements").add(log)
                db.collection("audit_logs").add(mapOf("action" to "PRODUCT_CREATE", "targetId" to product.id, "detail" to name.trim(), "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp()))
                onResult(Result.success(Unit))
            }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }
    fun deleteProduct(productId: String, onResult: (Result<Unit>) -> Unit) {
        val ref = db.collection("productos").document(productId)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            val name = snap.getString("name") ?: productId
            tx.delete(ref)
            val log = db.collection("audit_logs").document()
            tx.set(log, mapOf("action" to "PRODUCT_DELETE", "targetId" to productId, "detail" to name, "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp()))
            null
        }.addOnSuccessListener { onResult(Result.success(Unit)) }
            .addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun cancelStoreRequest(requestId: String, onResult: (Result<Unit>) -> Unit) {
        val ref = db.collection("requests").document(requestId)
        ref.update(mapOf("status" to "CANCELLED", "updatedAt" to FieldValue.serverTimestamp()))
            .addOnSuccessListener {
                db.collection("audit_logs").add(mapOf("action" to "REQUEST_CANCEL", "targetId" to requestId, "detail" to "Pedido cancelado por tienda", "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp()))
                onResult(Result.success(Unit))
            }.addOnFailureListener { onResult(Result.failure(it)) }
    }



    fun receiveStock(product: Product, quantity: Double, note: String, onResult: (Result<Unit>) -> Unit) {
        if (quantity <= 0) { onResult(Result.failure(IllegalArgumentException("La cantidad debe ser mayor que cero"))); return }
        val ref = db.collection("productos").document(product.id)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            val before = (snap.get("stock") as? Number)?.toDouble() ?: 0.0
            val after = before + quantity
            tx.update(ref, mapOf("stock" to after, "updatedAt" to FieldValue.serverTimestamp()))
            val movement = db.collection("movements").document()
            tx.set(movement, mapOf("productId" to product.id, "productName" to product.name, "type" to "RECEIPT", "quantity" to quantity, "beforeStock" to before, "afterStock" to after, "note" to note, "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp()))
            val audit = db.collection("audit_logs").document()
            tx.set(audit, mapOf("action" to "STOCK_RECEIPT", "targetId" to product.id, "detail" to "$quantity ${product.unit}: $note", "actorUid" to (auth.currentUser?.uid ?: ""), "createdAt" to FieldValue.serverTimestamp()))
            null
        }.addOnSuccessListener { onResult(Result.success(Unit)) }.addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun listenMovements(onChange: (List<Map<String, Any?>>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("movements").limit(200).addSnapshotListener { snapshot, error ->
            if (error != null) { onError(error); return@addSnapshotListener }
            onChange(snapshot?.documents.orEmpty().map { it.data.orEmpty() + ("_id" to it.id) }.sortedByDescending { (it["createdAt"] as? Timestamp)?.toDate()?.time ?: 0L })
        }
    }

    fun saveTemplate(user: AppUser, name: String, items: List<RequestItem>, onResult: (Result<Unit>) -> Unit) {
        if (name.isBlank() || items.isEmpty()) { onResult(Result.failure(IllegalArgumentException("Pon un nombre y agrega productos"))); return }
        val data = mapOf("name" to name.trim(), "storeId" to user.uid, "storeName" to user.name, "items" to items.map { mapOf("productId" to it.productId, "name" to it.name, "sku" to it.sku, "unit" to it.unit, "quantity" to it.quantity) }, "createdAt" to FieldValue.serverTimestamp())
        db.collection("order_templates").add(data).addOnSuccessListener { onResult(Result.success(Unit)) }.addOnFailureListener { onResult(Result.failure(it)) }
    }

    fun listenTemplates(storeId: String, onChange: (List<Map<String, Any?>>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration =
        db.collection("order_templates").whereEqualTo("storeId", storeId).addSnapshotListener { snapshot, error ->
            if (error != null) { onError(error); return@addSnapshotListener }
            onChange(snapshot?.documents.orEmpty().map { it.data.orEmpty() + ("_id" to it.id) })
        }
}
