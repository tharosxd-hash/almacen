CORRECCIÓN DE PERMISOS AL DESPACHAR — SOLICITUD ALMACÉN

Contenido:
- App Android con reconocimiento de roles warehouse/almacen y store/tienda.
- Reglas Firestore actualizadas para permitir al usuario de almacén autorizado actualizar productos, despachar pedidos y escribir movements/audit_logs.
- El descuento de stock continúa dentro de una transacción y solo se realiza al pasar el pedido a DISPATCHED, evitando descontar dos veces.

IMPORTANTE:
1. En Firebase Console > Firestore Database > Rules, publica el archivo firestore.rules incluido en este ZIP. El ZIP por sí solo no publica las reglas en Firebase.
2. En la colección users, el ID del documento debe ser exactamente el UID del usuario de Firebase Authentication.
3. El campo role del usuario de almacén puede ser warehouse o almacen. Para las tiendas, usa store o tienda.
4. El usuario de almacén debe haber iniciado sesión nuevamente después de cambiar su rol.
5. Si sigue apareciendo PERMISSION_DENIED, revisa el UID y role del usuario y confirma que la app apunta al proyecto Firebase correcto en app/google-services.json.

No se puede garantizar una compilación hasta que GitHub Actions ejecute el workflow en tu repositorio.
