# Solicitud Almacén — actualización de funciones

Proyecto Android Kotlin + Jetpack Compose + Firebase Auth/Firestore.

Incluye login por rol, carrito y envío de pedidos, categorías/búsqueda de productos, modo oscuro, gestión de productos, flujo de estados del pedido, confirmación de recepción, alertas de stock bajo (umbral inicial de 5), registro de entradas, movimientos/auditoría y exportación CSV mediante compartir texto.

## Importante
- El proyecto requiere `app/google-services.json` del proyecto Firebase existente.
- Las reglas incluidas en `firestore.rules` se deben publicar manualmente en Firebase Console (Firestore Database > Rules). Subir el ZIP a GitHub NO publica las reglas.
- La compilación debe ejecutarse con el Workflow de GitHub Actions proporcionado. No afirmar APK funcional hasta que el job termine en verde.
- Los documentos de `users/{uid}` deben tener `role: "warehouse"` o `role: "store"`.
- Las colecciones usadas son `productos`, `requests`, `users`, `movements`, `audit_logs` y `order_templates`.
- La exportación CSV se comparte como texto CSV desde Android; el usuario puede guardarlo o abrirlo en una hoja de cálculo.
