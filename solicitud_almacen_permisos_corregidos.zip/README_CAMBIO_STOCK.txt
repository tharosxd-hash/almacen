CORRECCIÓN: DESCONTAR STOCK AL DESPACHAR

Archivo modificado:
app/src/main/java/com/solicitudalmacen/data/FirebaseRepository.kt

Comportamiento:
- Aceptar pedido y marcar listo no cambian el inventario.
- Al pulsar Despachar, Firestore ejecuta una transacción: verifica el estado READY, lee el stock actual de cada producto, comprueba que haya suficiente cantidad, resta las unidades y registra el movimiento DISPATCH.
- El estado del pedido cambia a DISPATCHED en la misma transacción. Si algo falla, ni el stock ni el estado se guardan parcialmente.
- Si ya está DISPATCHED o RECEIVED, no vuelve a descontar.
- La pantalla muestra el error si el despacho falla.

IMPORTANTE:
No pude ejecutar una compilación Android en este entorno porque no está instalado Gradle. El ZIP contiene el proyecto corregido, pero hay que ejecutar el Workflow de GitHub Actions para confirmar que compila y genera el APK.
